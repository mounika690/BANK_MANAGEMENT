#ifndef BANK_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FILE_NAME "record.txt"  

// ANSI color codes
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define CYAN    "\033[36m"
#define BOLD    "\033[1m"

/*
 * STRUCT: Account
 * -----------------
 * Represents one bank record stored in the binary file.
 * Every account is stored/read as a fixed-size block of this struct.
 */
typedef struct {
    int acc_no;
    char name[50];
    int age;
    char address[100];
    char phone[20];
    char acc_type[20];
    float balance;
} Account;

// function prototypes 
void login();
void menu();
void create_account();
void view_accounts();
void search_account();
void deposit_money();
void withdraw_money();
void update_account();
void delete_account();


#endif