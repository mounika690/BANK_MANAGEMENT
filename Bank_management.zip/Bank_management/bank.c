#include"bank.h"

/*
 * READ_RECORD / WRITE_RECORD
 * ---------------------------
 * Used for: converting one Account struct to/from a single text line.
 * Format: acc_no|name|age|address|phone|acc_type|balance
 * These replace fread/fwrite so the file stays plain readable text.
 */
int read_record(FILE *fp, Account *a) {
    char line[300];
    if (!fgets(line, sizeof(line), fp))
        return 0;

    line[strcspn(line, "\n")] = '\0';

    char *token = strtok(line, "|");
    if (!token) return 0;
    a->acc_no = atoi(token);

    token = strtok(NULL, "|"); strcpy(a->name, token ? token : "");
    token = strtok(NULL, "|"); a->age = token ? atoi(token) : 0;
    token = strtok(NULL, "|"); strcpy(a->address, token ? token : "");
    token = strtok(NULL, "|"); strcpy(a->phone, token ? token : "");
    token = strtok(NULL, "|"); strcpy(a->acc_type, token ? token : "");
    token = strtok(NULL, "|"); a->balance = token ? atof(token) : 0;

    return 1;
}

void write_record(FILE *fp, Account *a) {
    fprintf(fp, "%d|%s|%d|%s|%s|%s|%.2f\n",
            a->acc_no, a->name, a->age, a->address, a->phone, a->acc_type, a->balance);
}

/*
 * MAIN
 * -----
 * Entry point: first authenticate user, then show the menu loop.
 */
int main() {
    login(); 
    menu();    
    return 0;
}

/*
 * LOGIN
 * ------
 * Used for: basic authentication before entering the system.
 * Compares user input against a hardcoded password.
 * If wrong, exits the program immediately.
 */
void login() {
    char pass[30];                          
    const char password[] = "iamlearning";  

    printf(BOLD CYAN "\n===== BANK MANAGEMENT SYSTEM =====\n" RESET);
    printf(CYAN "Enter Password: " RESET);
    scanf("%29s", pass);   

    if (strcmp(pass, password) != 0) {  
        printf(RED "Wrong Password!\n" RESET);
        exit(0);  
    }
}

/*
 * CREATE_ACCOUNT
 * ---------------
 * Used for: adding a new account record to the file.
 * - Opens file in "a+" mode (append + read, creates file if missing)
 * - Checks if account number already exists (prevents duplicates)
 * - Reads new account details from user
 * - Appends the new record to the end of the file
 */
void create_account() {
    FILE *fp = fopen(FILE_NAME, "a+");  
    Account a, temp;                     
    int exists = 0;                      

    printf(CYAN "\nAccount Number: " RESET);
    scanf("%d", &a.acc_no);

    rewind(fp);  
    while (read_record(fp, &temp)) {  
        if (temp.acc_no == a.acc_no) {
            exists = 1;  
            break;
        }
    }

    if (exists) {
        printf(RED "Account number already exists!\n" RESET);
        fclose(fp);
        return; 
    }

    
    printf(CYAN "Name: " RESET);
    scanf(" %49[^\n]", a.name);   

    printf(CYAN "Age: " RESET);
    scanf("%d", &a.age);

    printf(CYAN "Address: " RESET);
    scanf(" %99[^\n]", a.address);

    printf(CYAN "Phone: " RESET);
    scanf("%19s", a.phone);

    printf(CYAN "Account Type (Savings/Current): " RESET);
    scanf("%19s", a.acc_type);

    printf(CYAN "Initial Deposit: " RESET);
    scanf("%f", &a.balance);

    write_record(fp, &a);  
    fclose(fp);

    printf(GREEN "Account Created Successfully.\n" RESET);
}

/*
 * VIEW_ACCOUNTS
 * --------------
 * Used for: displaying ALL accounts stored in the file as a table.
 * Opens file in read-only text mode ("r") and loops through every record.
 */
void view_accounts() {
    FILE *fp = fopen(FILE_NAME, "r"); 
    Account a;

    if (!fp) {                          
        printf(RED "No records found.\n" RESET);
        return;
    }

    printf(BOLD YELLOW "\n%-10s %-20s %-8s %-15s %-12s %-12s\n" RESET,
           "ACC NO", "NAME", "AGE", "PHONE", "TYPE", "BALANCE");
    printf(YELLOW "------------------------------------------------------------------------\n" RESET);

    
    while (read_record(fp, &a)) {
        printf("%-10d %-20s %-8d %-15s %-12s " GREEN "%.2f\n" RESET,
               a.acc_no, a.name, a.age, a.phone, a.acc_type, a.balance);
    }

    fclose(fp);
}

/*
 * SEARCH_ACCOUNT
 * ---------------
 * Used for: finding ONE specific account by account number
 * and printing its full details.
 */
void search_account() {
    FILE *fp = fopen(FILE_NAME, "r");
    Account a;
    int acc, found = 0;  

    if (!fp) {
        printf(RED "No records found.\n" RESET);
        return;
    }

    printf(CYAN "Enter Account Number: " RESET);
    scanf("%d", &acc);

    while (read_record(fp, &a)) {
        if (a.acc_no == acc) {       
            found = 1;
            printf(GREEN "\nAccount Found\n" RESET);
            printf("Name    : %s\n", a.name);
            printf("Age     : %d\n", a.age);
            printf("Address : %s\n", a.address);
            printf("Phone   : %s\n", a.phone);
            printf("Type    : %s\n", a.acc_type);
            printf("Balance : " YELLOW "%.2f\n" RESET, a.balance);
            break;   
        }
    }

    if (!found)
        printf(RED "Account not found.\n" RESET);

    fclose(fp);
}

/*
 * DEPOSIT_MONEY
 * --------------
 * Used for: adding money to an existing account's balance.
 * - Text records have variable length, so we can't fseek/overwrite in place.
 * - Instead: read original file, write all records (with the match updated)
 *   into a temp file, then replace the original with the temp file.
 */
void deposit_money() {
    FILE *fp = fopen(FILE_NAME, "r");
    FILE *tempfp = fopen("temp.txt", "w");
    Account a;
    int acc;
    float amount;
    int found = 0;

    printf(CYAN "Account Number: " RESET);
    scanf("%d", &acc);

    while (read_record(fp, &a)) {
        if (a.acc_no == acc && !found) {
            found = 1;

            printf(CYAN "Amount to Deposit: " RESET);
            scanf("%f", &amount);

            a.balance += amount;   

            printf(GREEN "Deposit Successful. New Balance: %.2f\n" RESET, a.balance);
        }
        write_record(tempfp, &a);
    }

    fclose(fp);
    fclose(tempfp);
    remove(FILE_NAME);
    rename("temp.txt", FILE_NAME);

    if (!found)
        printf(RED "Account not found.\n" RESET);
}

/*
 * WITHDRAW_MONEY
 * ---------------
 * Used for: subtracting money from an existing account's balance.
 * Same rewrite-to-temp-file pattern as deposit_money(), but with a
 * balance check to prevent withdrawing more money than is available.
 */
void withdraw_money() {
    FILE *fp = fopen(FILE_NAME, "r");
    FILE *tempfp = fopen("temp.txt", "w");
    Account a;
    int acc;
    float amount;
    int found = 0;

    printf(CYAN "Account Number: " RESET);
    scanf("%d", &acc);

    while (read_record(fp, &a)) {
        if (a.acc_no == acc && !found) {
            found = 1;

            printf(CYAN "Amount to Withdraw: " RESET);
            scanf("%f", &amount);

            if (amount > a.balance) {     
                printf(RED "Insufficient Balance.\n" RESET);
            } else {
                a.balance -= amount;   
                printf(GREEN "Withdrawal Successful. New Balance: %.2f\n" RESET, a.balance);
            }
        }
        write_record(tempfp, &a);
    }

    fclose(fp);
    fclose(tempfp);
    remove(FILE_NAME);
    rename("temp.txt", FILE_NAME);

    if (!found)
        printf(RED "Account not found.\n" RESET);
}

/*
 * UPDATE_ACCOUNT
 * ---------------
 * Used for: editing an existing account's address and phone number.
 * (Does NOT allow changing acc_no, name, age, type, or balance here.)
 * Same rewrite-to-temp-file pattern as deposit/withdraw.
 */
void update_account() {
    FILE *fp = fopen(FILE_NAME, "r");
    FILE *tempfp = fopen("temp.txt", "w");
    Account a;
    int acc, found = 0;

    printf(CYAN "Account Number: " RESET);
    scanf("%d", &acc);

    while (read_record(fp, &a)) {
        if (a.acc_no == acc && !found) {
            found = 1;

            printf(CYAN "New Address: " RESET);
            scanf(" %99[^\n]", a.address);  

            printf(CYAN "New Phone: " RESET);
            scanf("%19s", a.phone);        

            printf(GREEN "Account Updated.\n" RESET);
        }
        write_record(tempfp, &a);
    }

    fclose(fp);
    fclose(tempfp);
    remove(FILE_NAME);
    rename("temp.txt", FILE_NAME);

    if (!found)
        printf(RED "Account not found.\n" RESET);
}

/*
 * DELETE_ACCOUNT
 * ---------------
 * Used for: removing an account record permanently.
 * Strategy:
 * 1. Open original file for reading, and a NEW temp file for writing
 * 2. Copy every record EXCEPT the one to delete into temp file
 * 3. Delete original file, rename temp file to original file's name
 */
void delete_account() {
    FILE *fp = fopen(FILE_NAME, "r");        
    FILE *tempfp = fopen("temp.txt", "w");   
    Account a;
    int acc, found = 0;

    printf(CYAN "Account Number: " RESET);
    scanf("%d", &acc);

    while (read_record(fp, &a)) {
        if (a.acc_no == acc) {
            found = 1;
            continue;   
        }
        write_record(tempfp, &a);  
    }

    fclose(fp);
    fclose(tempfp);

    remove(FILE_NAME);         
    rename("temp.txt", FILE_NAME);  

    if (found)
        printf(GREEN "Account Deleted Successfully.\n" RESET);
    else
        printf(RED "Account not found.\n" RESET);
}

/*
 * MENU
 * -----
 * Used for: main interaction loop.
 * Displays options, reads user's numeric choice, and calls
 * the corresponding function via a switch statement.
 * Runs forever (while(1)) until user chooses option 8 (Exit).
 */
void menu() {
    int choice;

    while (1) {   
        printf(BOLD YELLOW "\n\n===== MENU =====\n" RESET);
        printf(CYAN "1. Create Account\n" RESET);
        printf(CYAN "2. View All Accounts\n" RESET);
        printf(CYAN "3. Search Account\n" RESET);
        printf(CYAN "4. Deposit Money\n" RESET);
        printf(CYAN "5. Withdraw Money\n" RESET);
        printf(CYAN "6. Update Account\n" RESET);
        printf(CYAN "7. Delete Account\n" RESET);
        printf(CYAN "8. Exit\n" RESET);
        printf(BOLD "Enter Choice: " RESET);
        scanf("%d", &choice);

        switch (choice) {
            case 1: create_account(); break;
            case 2: view_accounts();  break;
            case 3: search_account(); break;
            case 4: deposit_money();  break;
            case 5: withdraw_money(); break;
            case 6: update_account(); break;
            case 7: delete_account(); break;
            case 8:
                printf(GREEN "Thank You.\n" RESET);
                exit(0);   
            default:
                printf(RED "Invalid Choice.\n" RESET);
        }
    }
}